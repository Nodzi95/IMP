#include <fitkitlib.h>
#include <keyboard/keyboard.h>
#include <lcd/display.h>

#define MAX_PACKET 39
#define MAX_BYTE 8

#define ZERO1 12
#define ZERO2 21
#define ZERO3 30
#define STOP 39

#define SOUND	BIT0
#define set_sound(on){\
	P6DIR |= SOUND;\
	P6OUT = (on) ? (P6OUT & ~SOUND) : (P6OUT | SOUND);\
}
#define flip() {P6OUT ^= SOUND;}

int state = 0;
char last_ch; //naposledy precteny znak
int times = 0;

int packet[MAX_PACKET];
int index = 0;

int time_one = 3276;			//originaly 58 us
int time_zero = 32768;		//originaly 100 us

int byte1[MAX_BYTE] = {1,0,1,1,1,0,0,0};
int byte2[MAX_BYTE] = {1,0,1,1,1,0,0,0};
int byte3[MAX_BYTE] = {1,0,1,1,1,0,0,0};

void print_user_help(void) { }

unsigned char decode_user_cmd(char *cmd_ucase, char *cmd)
{
  return CMD_UNKNOWN;
}

void fpga_initialized()
{
}

void make_packet(){
	int i = 0;
	int bit1 = 0;
	int bit2 = 0;
	int bit3 = 0;
	for(i = 0; i <= MAX_PACKET; i++){
		if(i < ZERO1){
			packet[i] = 1;
		}
		else if(i == ZERO1){
			packet[i] = 0;	
		}
		else if(i > ZERO1 && i < ZERO2){		
			packet[i] = byte1[bit1++];
		}
		else if(i == ZERO2){
			packet[i] = 0;
		}
		else if(i > ZERO2 && i < ZERO3){	
			packet[i] = byte2[bit2++];
		}
		else if(i == ZERO3){
			packet[i] = 0;
		}
		else if(i > ZERO3 && i < STOP){
			packet[i] = byte3[bit3++];
		}
		else if(i == STOP){
			packet[i] = 1;
		}
	}
}
/*
void print_packet(){
	int i = 0;
	for (i = 0; i <= MAX_PACKET; i++){
		if(i == 12 || i == 13 || i == 21 || i == 22 || i == 30 || i == 31 || i == 39) printf(" ");
		printf("%d", packet[i]);
	}
	printf("\n");
}*/

int keyboard_idle(){
  	char ch;
  	ch = key_decode(read_word_keyboard_4x4());
  	if(ch != last_ch){
  		last_ch = ch;
  		if (ch != 0){		  		
      		LCD_clear();
      		switch(ch){
			case '2':
				make_packet();
				TAR = 0;
				CCR0 = 0;
				TACTL = TASSEL1 + MC_2;
				LCD_append_char('U');
				LCD_append_char('P');
				break;
			case '4':
				LCD_append_char('L');
				break;
			case '5':
				if(state){
					LCD_append_char('S');
					LCD_append_char('T');
					LCD_append_char('O');
					LCD_append_char('P');
					state = 0;				
				}
				else{
					LCD_append_char('G');
					LCD_append_char('O');
					state = 1;	
				}
				break;
			case '6':
				LCD_append_char('R');
				break;
			case '8':
				LCD_append_char('D');
				LCD_append_char('O');
				LCD_append_char('W');
				LCD_append_char('N');
				break;
			default:
				LCD_append_char('N');
				break;
			} 
    	}
  	}
  	return 0;
}

int main(void)
{
  last_ch = 0;

  initialize_hardware();
  keyboard_init();
  LCD_init();
  LCD_clear();
  CCTL0 = CCIE;
  TACTL = MC_0;
  set_sound(1);
  while (1)
  {
    keyboard_idle();  // obsluha klavesnice
    terminal_idle();  // obsluha terminalu
  }         
}


interrupt (TIMERA0_VECTOR) Timer_A(void){
	//LCD_clear();
	if(index <= 39){
		times++;
		if(packet[index] == 1){
			LCD_append_char('1');
			if(times == 1){
				
				set_sound(1);
			}
			else{
				set_sound(0);
			}
			CCR0 += time_one;
		}
		else{
			LCD_append_char('0');
			if(times == 1){
				set_sound(1);
			}
			else{
				set_sound(0);
			}
			CCR0 += time_zero;
		}
		if(times == 2){
			index++;
			times = 0;
		}
	}
	else{
		TACTL = MC_0;
		index = 0;
	}	
}
